import "../node_modules/bootstrap/dist/css/bootstrap.min.css";
import "./App.css";
import Home from "./components/Home";
// import Home2 from "./components/Home2";

function App() {
  return (
    <div>
      <Home />
    </div>
  );
}

export default App;
