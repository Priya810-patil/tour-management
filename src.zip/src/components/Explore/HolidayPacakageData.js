
export default function HolidayPacakageData({data}){
    return(
        <div>
            {data}
            </div>
           )
    }