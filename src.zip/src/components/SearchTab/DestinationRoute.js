import SearchForm from "./SearchForm";



export default function DestinationRoute() {


    return (
        <>
            <SearchForm />
        </>
    )
}