const backgroundItems = [
  {
    className: "bg",
    src: "images/assets/bg_img.jpg",
    title: "We are Here To Make your Trip More Memorable",
    text: "customize and book best holiday package",
  },
];

export default backgroundItems;
