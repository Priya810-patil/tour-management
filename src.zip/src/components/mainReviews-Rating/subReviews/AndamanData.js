const andamanDetails = [
    {
      id: 1,
      heading: "No Reviews",
      details: "",
    //   url: "",
    },
  ];
  
  export default andamanDetails;
  